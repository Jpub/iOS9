//: Playground - noun: a place where people can play

import UIKit

print("Welcome to Swift")

/*:
# Welcome to Playgrounds
This is your *first* playground which is intented to demonstrate:
* The use of **Quick Look**
* Placing results **in-line** with the code
*/

var x = 10

for index in 1...20 {
    let y = index * x
    x -= 1
}
