//
//  MyDrawKit.h
//  MyDrawKit
//
//  Created by Neil Smyth on 10/7/16.
//  Copyright © 2016 eBookFrenzy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MyDrawKit.
FOUNDATION_EXPORT double MyDrawKitVersionNumber;

//! Project version string for MyDrawKit.
FOUNDATION_EXPORT const unsigned char MyDrawKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyDrawKit/PublicHeader.h>


