//: [Previous](@previous)

import UIKit

var str = "Hello, playground"

let myLabel = UILabel(frame: CGRectMake(0, 0, 200, 50))
myLabel.backgroundColor = UIColor.redColor()
myLabel.text = "Hello Swift"
myLabel.textAlignment = .Center
myLabel.font = UIFont(name: "Georgia", size: 24)


let image = UIImage(named: "waterfall")
//: [Next](@next)
