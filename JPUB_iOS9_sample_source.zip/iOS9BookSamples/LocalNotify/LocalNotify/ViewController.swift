//
//  ViewController.swift
//  LocalNotify
//
//  Created by Neil Smyth on 9/3/15.
//  Copyright © 2015 eBookFrenzy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let app = UIApplication.sharedApplication()

        let notificationSettings = UIUserNotificationSettings(forTypes: 
            [.Alert, .Sound],
            categories: nil)

        app.registerUserNotificationSettings(notificationSettings)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

