//
//  Contacts.swift
//  CoreDataDemo
//
//  Created by Neil Smyth on 9/2/15.
//  Copyright © 2015 eBookFrenzy. All rights reserved.
//

import Foundation
import CoreData

class Contacts: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
